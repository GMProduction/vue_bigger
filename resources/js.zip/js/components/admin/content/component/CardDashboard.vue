<template>
  <div>
      Home
  </div>
</template>

<script>
// @ is an alias to /src

export default {
  
}
</script>
